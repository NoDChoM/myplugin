package com.NDCM.AntiKillAura.Events;

import com.NDCM.AntiKillAura.KillAuraTest;
import com.NDCM.AntiKillAura.PacketReader;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.ArrayList;

public class Join implements Listener {
    private static ArrayList<Player> allPlayers = new ArrayList<Player>();

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        try {
            PacketReader reader = new PacketReader();
            reader.inject(event.getPlayer());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        try {
            PacketReader reader = new PacketReader();
            reader.uninject(event.getPlayer());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}