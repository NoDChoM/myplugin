package com.NDCM.AntiKillAura.Events;

import com.NDCM.AntiKillAura.*;

import net.minecraft.server.v1_12_R1.*;

import org.apache.commons.lang.RandomStringUtils;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.craftbukkit.v1_12_R1.entity.CraftPlayer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static org.bukkit.Bukkit.getServer;

public class ClickNPC implements Listener {
    static Map<Integer, Integer> KillAuraClickTimes = new HashMap<Integer, Integer>();
    static ConfigReader data = new ConfigReader(Main.getPlugin(Main.class));
    static BanDataReader BanInfo = new BanDataReader(Main.getPlugin(Main.class));
    static Integer MaxClick = data.getConfig().getInt("Settings.Click");
    static String AppealURL = data.getConfig().getString("Settings.AppealUrl");

    @EventHandler
    public void onClick(AnyClickNPC event) {
        if (KillAuraTest.getWatchdogData().get(event.getPlayer()) == event.getNPC()) {
            if (KillAuraClickTimes.containsKey(event.getNPC().getId())) {
                KillAuraClickTimes.put(event.getNPC().getId(), KillAuraClickTimes.get(event.getNPC().getId()) + 1);
                if (MaxClick != null) {
                    if (KillAuraClickTimes.get(event.getNPC().getId()) >= MaxClick) {
                        PlayerConnection connection = ((CraftPlayer) event.getPlayer()).getHandle().playerConnection;
                        connection.sendPacket(new PacketPlayOutPlayerInfo(PacketPlayOutPlayerInfo.EnumPlayerInfoAction.REMOVE_PLAYER, event.getNPC()));
                        connection.sendPacket(new PacketPlayOutEntityDestroy(event.getNPC().getId()));
                        String reasonID = RandomStringUtils.randomNumeric(7);
                        String banID = RandomStringUtils.randomAlphanumeric(8).toUpperCase();
                        BanInfo.getConfig().set("players." + event.getPlayer().getUniqueId().toString() + ".Username", event.getPlayer().getName());
                        BanInfo.getConfig().set("players." + event.getPlayer().getUniqueId().toString() + ".Reason", "WATCHDOG CHEAT DETECTION");
                        BanInfo.getConfig().set("players." + event.getPlayer().getUniqueId().toString() + ".BannedFrom", "Watchdog");
                        BanInfo.getConfig().set("players." + event.getPlayer().getUniqueId().toString() + ".BanID", banID);
                        BanInfo.saveConfig();
                        Bukkit.getBanList(BanList.Type.NAME).addBan(event.getPlayer().getName(), ChatColor.RED + "You are permanently banned from this server!\n\n" + ChatColor.WHITE + "Reason: " + ChatColor.WHITE + "WATCHDOG CHEAT DETECTION " + ChatColor.GRAY + ChatColor.ITALIC + "[GG-" + reasonID + "]\n" + ChatColor.WHITE + "Appeal at: " + ChatColor.BLUE + ChatColor.UNDERLINE + AppealURL + "\n\n" + ChatColor.GRAY + "Ban ID: " + ChatColor.WHITE + "#" + banID + "\nConnect the 'Appeal at' server to appeal.\nSharing your Ban ID may affect the processing of your appeal!", (Date) null, "WatchdogBan");
                        event.getPlayer().kickPlayer(ChatColor.RED + "You are permanently banned from this server!\n\n" + ChatColor.GRAY + "Reason: " + ChatColor.WHITE + "WATCHDOG CHEAT DETECTION " + ChatColor.GRAY + ChatColor.ITALIC + "[GG-" + reasonID + "]\n" + ChatColor.WHITE + "Appeal at: " + ChatColor.BLUE + ChatColor.UNDERLINE + AppealURL + "\n\n" + ChatColor.GRAY + "Ban ID: " + ChatColor.WHITE + "#" + banID + "\nConnect the 'Appeal at' to appeal.\nSharing your Ban ID may affect the processing of your appeal!");
                    }
                } else {
                    getServer().getConsoleSender().sendMessage(ChatColor.RED + "Config.yml 파일을 알맞은 형식으로 입력해주세요.");
                    Bukkit.getPluginManager().disablePlugin(Main.getPlugin(Main.class));
                }
            } else {
                KillAuraClickTimes.put(event.getNPC().getId(), 1);
                return;
            }
        }
    }

}

