package com.NDCM.AntiKillAura;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import net.minecraft.server.v1_12_R1.*;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_12_R1.CraftServer;
import org.bukkit.craftbukkit.v1_12_R1.CraftWorld;
import org.bukkit.craftbukkit.v1_12_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

import static org.bukkit.Bukkit.getServer;

public class KillAuraTest implements Listener {

    private static List<EntityPlayer> NPC = new ArrayList<EntityPlayer>();
    private static ArrayList<Player> allPlayers = new ArrayList<Player>();
    private static Map<Player, EntityPlayer> TestingPlayers = new HashMap<Player, EntityPlayer>();
    private static Map<Player, Long> TestTimes = new HashMap<Player, Long>();
    private static ConfigReader data = new ConfigReader(Main.getPlugin(Main.class));
    private static boolean invisible = data.getConfig().getBoolean("Settings.AppealUrl");
    private static Integer TestTime = data.getConfig().getInt("Settings.Time");

    public static void CreateWatchdog(CommandSender reporter, Player player) {
        if (TestingPlayers.containsKey(player)) {
            reporter.sendMessage(ChatColor.YELLOW + "[" + ChatColor.RED + " KillAura " + ChatColor.YELLOW + "]" + ChatColor.WHITE + " : " + ChatColor.RED + player.getName() + "은/는 현재 핵검사중 입니다.");
            return;
        }
        for(Player players : Bukkit.getOnlinePlayers())
            allPlayers.add(players);
        int random = new Random().nextInt(allPlayers.size());
        Player RPLAYER = allPlayers.get(random);
        MinecraftServer server = ((CraftServer) getServer()).getServer();
        WorldServer world = ((CraftWorld) Bukkit.getWorld(player.getWorld().getName())).getHandle();
        GameProfile gameProfile = new GameProfile(UUID.randomUUID(), RPLAYER.getName());
        EntityPlayer npc = new EntityPlayer(server, world, gameProfile, new PlayerInteractManager(world));
        npc.setLocation(player.getLocation().getX(), player.getLocation().getY(), player.getLocation().getZ(), player.getLocation().getYaw(), player.getLocation().getPitch());
        String[] name = getSkin(RPLAYER);
        gameProfile.getProperties().put("textures", new Property("textures", name[0], name[1]));
        npc.setInvisible(invisible);
        addNPCPacket(npc);
        NPC.add(npc);
        TestingPlayers.put(player, npc);
        CheckKillAura(npc, player);
    }

    public static Map getWatchdogData(){
        return TestingPlayers;
    }

    public static Location getLocationAroundCircle(Location center, double radius, double angleInRadian) {
        double x = center.getX() + radius * Math.cos(angleInRadian);
        double z = center.getZ() + radius * Math.sin(angleInRadian);
        double y = center.getY();

        Location loc = new Location(center.getWorld(), x, y, z);
        Vector difference = center.toVector().clone().subtract(loc.toVector());
        loc.setDirection(difference);
        return loc;
    }

    public static void CheckKillAura(EntityPlayer npc, Player player) {
        PlayerConnection connection = ((CraftPlayer)player).getHandle().playerConnection;
        Random random = new Random();
        final double radius = 3;
        final double radPerSec = 6;
        final double radPerTick = radPerSec / 20;
        TestTimes.put(player, System.currentTimeMillis() + (TestTime * 1000));

        new BukkitRunnable() {
            int tick = 0;
            public void run() {
                try {
                    if (!(TestingPlayers.containsKey(player))) {
                        cancel();
                    }
                    if (TestTimes.get(player) < System.currentTimeMillis()) {
                        PlayerConnection connection = ((CraftPlayer) player).getHandle().playerConnection;
                        connection.sendPacket(new PacketPlayOutPlayerInfo(PacketPlayOutPlayerInfo.EnumPlayerInfoAction.REMOVE_PLAYER, TestingPlayers.get(player)));
                        connection.sendPacket(new PacketPlayOutEntityDestroy(TestingPlayers.get(player).getId()));
                        TestTimes.remove(player);
                        TestingPlayers.remove(player);
                        cancel();
                    }
                    tick++;
                    Location loc = getLocationAroundCircle(player.getLocation(), radius, radPerTick * tick);
                    npc.setLocation(loc.getX(), loc.getY(), loc.getZ(), random.nextInt(360) - 180, random.nextInt(180) - 90);
                    connection.sendPacket(new PacketPlayOutEntityTeleport(npc));
                } catch (Exception e) {
                    try {
                        PlayerConnection connection = ((CraftPlayer) player).getHandle().playerConnection;
                        connection.sendPacket(new PacketPlayOutPlayerInfo(PacketPlayOutPlayerInfo.EnumPlayerInfoAction.REMOVE_PLAYER, npc));
                        connection.sendPacket(new PacketPlayOutEntityDestroy(npc.getId()));
                    } catch (Exception er) {
                        er.printStackTrace();
                    }
                    cancel();
                }
            }
        }.runTaskTimer(Main.getPlugin(Main.class), 0L, 0L);
    }

    private static String[] getSkin(Player player) {
        EntityPlayer playerNMS = ((CraftPlayer) player).getHandle();
        GameProfile profile = playerNMS.getProfile();
        Property property = profile.getProperties().get("textures").iterator().next();
        String texture = property.getValue();
        String signature = property.getSignature();
        return new String[] {texture, signature};
    }

    public static void addNPCPacket(EntityPlayer npc) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            PlayerConnection connection = ((CraftPlayer)player).getHandle().playerConnection;
            connection.sendPacket(new PacketPlayOutPlayerInfo(PacketPlayOutPlayerInfo.EnumPlayerInfoAction.ADD_PLAYER, npc));
            connection.sendPacket(new PacketPlayOutNamedEntitySpawn(npc));
            connection.sendPacket(new PacketPlayOutEntityEffect());
            connection.sendPacket(new PacketPlayOutEntityHeadRotation(npc, (byte) (npc.yaw * 256 / 360)));
        }
    }

    public static List<EntityPlayer> getNPCs() { return NPC; }
}