package com.NDCM.AntiKillAura;

import com.NDCM.AntiKillAura.Events.ClickNPC;
import com.NDCM.AntiKillAura.Events.Join;
import net.minecraft.server.v1_12_R1.EntityPlayer;
import net.minecraft.server.v1_12_R1.PacketPlayOutEntityDestroy;
import net.minecraft.server.v1_12_R1.PacketPlayOutPlayerInfo;
import net.minecraft.server.v1_12_R1.PlayerConnection;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_12_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;


public class Main extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        this.getServer().getPluginManager().registerEvents(new Join(), this);
        this.getServer().getPluginManager().registerEvents(new ClickNPC(), this);
        this.getServer().getPluginManager().registerEvents(new KillAuraTest(), this);
        getServer().getConsoleSender().sendMessage(ChatColor.YELLOW + "[" + ChatColor.RED + " KillAura " + ChatColor.YELLOW + "]" + ChatColor.WHITE + " : " + ChatColor.GREEN + "플러그인이 활성화 되었습니다.");
        ConfigReader data = new ConfigReader(Main.getPlugin(Main.class));
        if (data.getConfig().get("Settings.Click") == null || data.getConfig().get("Settings.Time") == null || data.getConfig().get("Settings.AppealUrl") == null || data.getConfig().get("Settings.invisible") == null || ((data.getConfig().get("Settings.invisible").equals("true")) == true || (data.getConfig().get("Settings.invisible").equals("false")) == true)) {
            getServer().getConsoleSender().sendMessage(ChatColor.YELLOW + "["+ChatColor.RED + " KillAura "  + ChatColor.YELLOW + "]"+ChatColor.WHITE+" : " + ChatColor.RED + "Config.yml 파일에 필수 입력항목이 없거나 비어있습니다.");
            Bukkit.getPluginManager().disablePlugin(Main.getPlugin(Main.class));
        }
        System.out.println(data.getConfig().get("Settings.Click")+""+data.getConfig().get("Settings.Time")+""+data.getConfig().get("Settings.AppealUrl"));
        if (!Bukkit.getOnlinePlayers().isEmpty())
            for (Player player : Bukkit.getOnlinePlayers()) {
                PacketReader reader = new PacketReader();
                reader.inject(player);
            }
    }

    @Override
    public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            PacketReader reader = new PacketReader();
            reader.uninject(player);
        }
        getServer().getConsoleSender().sendMessage(ChatColor.YELLOW + "["+ChatColor.RED + " KillAura " + ChatColor.YELLOW + "]"+ChatColor.WHITE+" : "+ChatColor.RED + "플러그인이 비활성화 되었습니다.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("wdr")) {
            if (args.length != 0) {
                if (this.getServer().getPlayer(args[0]) != null) {
                    KillAuraTest.CreateWatchdog(sender, this.getServer().getPlayer(args[0]));
                } else {
                    sender.sendMessage(ChatColor.YELLOW + "["+ChatColor.RED + " KillAura " + ChatColor.YELLOW + "]"+ChatColor.WHITE+" : "+ChatColor.RED + args[0] + "님 현재 온라인이 아닙니다.");
                }
                return true;
            } else {
                return false;
            }
        }
        if (label.equalsIgnoreCase("watchdogreload")) {
            PlayerConnection connection = ((CraftPlayer) sender).getHandle().playerConnection;
            for (EntityPlayer npc : KillAuraTest.getNPCs()) {
                connection.sendPacket(new PacketPlayOutPlayerInfo(PacketPlayOutPlayerInfo.EnumPlayerInfoAction.REMOVE_PLAYER, npc));
                connection.sendPacket(new PacketPlayOutEntityDestroy(npc.getId()));
            }
            Bukkit.getPluginManager().disablePlugin(Main.getPlugin(Main.class));
            Bukkit.getPluginManager().enablePlugin(Main.getPlugin(Main.class));
            sender.sendMessage(ChatColor.YELLOW + "["+ChatColor.RED + " KillAura " + ChatColor.YELLOW + "]"+ChatColor.GREEN + " : " + "성공적으로 리로드가 되었습니다.");
            return true;
        }
        return false;
    }
}
